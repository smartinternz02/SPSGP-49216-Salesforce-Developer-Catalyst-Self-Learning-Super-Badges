# Intructions to pass this challenge
* from Developer Console Menu : Debug > Open Execute Anonymous Window
* delete all previous codes
* execute this line of code : WarehouseCalloutService.runWarehouseEquipmentSync();
* now check to pass the challenge (click 'Check Challenge')
